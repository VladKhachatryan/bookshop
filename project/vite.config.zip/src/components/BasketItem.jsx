export const BasketItem=({title,price,count,id,addCount})=>{
    return <tr>
        <td>{title}</td>
        <td>{price}</td>
        <td>{count}</td>
        <td>{price*count}</td>
        <td>
            <button>remove</button>
            <button onClick={()=>addCount(id)}>+</button>
            <button>-</button>
        </td>
    </tr>
}